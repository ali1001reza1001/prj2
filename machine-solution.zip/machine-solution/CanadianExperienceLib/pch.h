/**
 * @file pch.h
 * @author your_name_here
 */

#ifndef CANADIANEXPERIENCELIB_PCH_H
#define CANADIANEXPERIENCELIB_PCH_H

#include <wx/wxprec.h>
#ifndef WX_PRECOMP
#include <wx/wx.h>
#endif

#include <wx/xml/xml.h>
#include <wx/graphics.h>

#endif //CANADIANEXPERIENCELIB_PCH_H
