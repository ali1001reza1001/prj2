/**
 * @file Crank.cpp
 * @author Charles Owen
 */

#include "pch.h"
#include "Crank.h"

/// The width of the crank on the screen in pixels
const int CrankWidth = 10;

/// The depth of the crank away from the screen in pixels
const int CrankDepth = 20;

/// The length of the crank in pixels
const int CrankLength = 50;

/// The diameter to draw the crank handle
const int HandleDiameter = 7;

/// How long the handles is in pixels
const int HandleLength = 40;

/// How much to the left of the crank X the handle starts in pixels
const int HandleStartX = -10;

/// Crank color
const wxColour CrankColor = wxColour(220, 220, 220);

/// Line color for the rod
const wxColour CrankHandleLineColor = wxColour(100, 100, 100);

/**
 * Constructor
 */
Crank::Crank()
{
    mHandle.SetSize(HandleDiameter, HandleLength);
    mHandle.SetColour(CrankColor);
    mHandle.SetLines(CrankHandleLineColor, 1, 4);
}

/**
 * Reset the crank to time zero
 */
void Crank::Reset()
{
    Component::Reset();
    mRotation = 0;
    mSource.SetRotation(mRotation);
}

/**
 * Set the crank time (rotation)
 * @param time Time in seconds
 */
void Crank::SetTime(double time)
{
    Component::SetTime(time);

    mRotation = time * mSpeed;
    mSource.SetRotation(mRotation);
}

/**
 * Draw the crank
 * @param graphics Graphics device to draw on
 */
void Crank::Draw(std::shared_ptr<wxGraphicsContext> graphics)
{
    Component::Draw(graphics);

    int x = GetX();

    double y1 = GetY();

    double angle = mRotation * M_PI * 2;    // In radians
    double s = sin(angle);
    double c = cos(angle);

    double handleY = GetY() + c * CrankLength;

    mHandle.Draw(graphics, GetX() + HandleStartX, handleY, mRotation);

    wxBrush crankBrush(CrankColor);
    graphics->SetBrush(crankBrush);
    graphics->SetPen(*wxBLACK_PEN);

    //graphics->StrokeLine(x, y1, x + 200, y1);

    if(handleY > y1)
    {
        graphics->DrawRectangle(x - CrankWidth / 2, y1- CrankDepth / 2, CrankWidth, handleY - y1 + CrankDepth);
    }
    else
    {
        graphics->DrawRectangle(x - CrankWidth / 2, handleY- CrankDepth / 2, CrankWidth, y1 - handleY + CrankDepth);
    }


}
