/**
 * @file Component.h
 *
 * @author Anik Momtaz
 * @author Charles B. Owen
 */

#pragma once

class Machine;
class Sink;

/**
 * Abstract base class for machine parts
 */
class Component
{
private:
    /// Pointer to the owning machine
    Machine *mMachine;

    /// Machine's position
    wxPoint mPosition;


protected:
    Component();

public:
    /**
     * Set the machine that owns this component
     * @param machine Machine that owns the component
     */
	virtual void SetMachine(Machine *machine) { mMachine = machine; }

    /**
     * Get the machine that owns this component
     * @return Machine that owns the component
     */
	Machine *GetMachine() { return mMachine; }

    virtual void Draw(std::shared_ptr<wxGraphicsContext> graphics);

    /**
     * Draw the component in the second drawing group
     * @param graphics Graphics device to draw on
     * @param x X location to draw the machine
     * @param y Y location to draw the machine
     */
    virtual void DrawLast(std::shared_ptr<wxGraphicsContext> graphics) {}

    /**
     * Set the component position as a point
     * @param position Position in pixels
     */
	virtual void SetPosition(wxPoint position) { mPosition = position; }

    /**
     * Set the position of a component as x,y
     * @param x X Position in pixels
     * @param y Y Position in pixels
     */
	void SetPosition(int x, int y) { SetPosition(wxPoint(x, y)); }

    /**
     * Get the component position
     * @return Position in pixels
     */
	wxPoint GetPosition() { return mPosition; }

    /**
     * Get the component X position
     * @return X position in pixels
     */
	int GetX() { return mPosition.x; }

    /**
     * Get the component Y position
     * @return Y position in pixels
     */
	int GetY() { return mPosition.y; }

    /**
     * Set the machine absolute time
     * @param time Time in seconds
     */
    virtual void SetTime(double time) {}

    /**
     * Advance the animation in time
     * @param delta Amount to advance in seconds
     */
	virtual void Advance(double delta) {}

    /**
     * Reset the animation to time zero
     */
	virtual void Reset() {};




};

