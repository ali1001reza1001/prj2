/**
 * @file IMutable.h
 * @author Charles Owen
 *
 * Interface for any class that can be muted.
 */

#ifndef CANADIANEXPERIENCE_MACHINELIB_IMUTABLE_H
#define CANADIANEXPERIENCE_MACHINELIB_IMUTABLE_H

/**
 * Interface for any class that can be muted.
 */
class IMutable
{
public:
    /**
     * Set the mute status
     * @param mute
     */
    virtual void SetMute(bool mute) = 0;
};

#endif //CANADIANEXPERIENCE_MACHINELIB_IMUTABLE_H
