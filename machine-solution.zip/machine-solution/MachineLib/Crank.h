/**
 * @file Crank.h
 * @author Charles Owen
 *
 * The hand crank
 */

#ifndef CANADIANEXPERIENCE_MACHINELIB_CRANK_H
#define CANADIANEXPERIENCE_MACHINELIB_CRANK_H

#include "Component.h"
#include "Cylinder.h"
#include "RotationSource.h"

/**
 * The hand crank
 */
class Crank : public Component
{
private:
    /// The crank handle
    cse335::Cylinder mHandle;

    /// Crank rotation speed in turns per second
    double mSpeed = 1.0;

    /// Current crank rotation in turns
    double mRotation = 0;

    /// The rotation source for this component
    RotationSource mSource;

public:
    Crank();
    void Draw(std::shared_ptr<wxGraphicsContext> graphics) override;
    void SetTime(double time) override;

    /**
     * Set the crank speed in turns per second
     * @param speed Speed in turns per second
     */
    void SetSpeed(double speed) { mSpeed = speed; }
    void Reset() override;

    /**
     * Get the rotation source
     * @return Rotation source
     */
    RotationSource* GetSource() {return &mSource;}
};

#endif //CANADIANEXPERIENCE_MACHINELIB_CRANK_H
