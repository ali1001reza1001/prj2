/**
 * @file Cam.cpp
 * @author Charles Owen
 */

#include "pch.h"
#include "Cam.h"

/// Width of the cam on the screen in pixels
const double CamWidth = 17;

/// Cam diameter
const double CamDiameter = 60;

/// How big is the hole in the cam?
const double HoleSize = 8;

/// The key image
const std::wstring KeyImage = L"/key.png";

/// The key image size
const int KeyImageSize = 20;

/// The amount the key drops into the hole
const int KeyDrop = 10;

/**
 * Constructor
 * @param imagesDir The directory we get the images from
 */
Cam::Cam(std::wstring imagesDir)
{
    mKey.SetImage(imagesDir + KeyImage);
    mKey.Rectangle(-KeyImageSize/2, 0, KeyImageSize, KeyImageSize);
}

/**
 * Handle a rotation from a source
 * @param rotation Rotation in turns
 */
void Cam::SetRotation(double rotation)
{
    mRotation = rotation;
}

/**
 * Draw the can
 * @param graphics Graphics device to draw on
 */
void Cam::Draw(std::shared_ptr<wxGraphicsContext> graphics)
{
    Component::Draw(graphics);

    auto x = GetX();
    auto y = GetY();

    double leftX = x - CamWidth / 2;
    double topY = y - CamDiameter / 2;

    // The angle from top to bottom of the hole
    double circumference = CamDiameter * M_PI;
    double holeAngleRangeTurns = HoleSize / circumference;
    double holeAngleRange = holeAngleRangeTurns * M_PI * 2;

    // I add 1 to ensure this is never negative
    double holeAngleTurns = mRotation-mHoleAngle+1;
    double holeAngle = holeAngleTurns * M_PI * 2;

    // We only need this in the range 0 to 1
    holeAngleTurns = fmod(holeAngleTurns, 1);

    // Is the key dropping?
    bool drop = holeAngleTurns < holeAngleRangeTurns / 2 ||
                holeAngleTurns > 1 - (holeAngleRangeTurns / 2);

    graphics->SetPen(*wxBLACK_PEN);
    graphics->SetBrush(*wxWHITE_BRUSH);

    mKey.DrawPolygon(graphics, x, y - CamDiameter/2 + (drop ? KeyDrop : 0));

    graphics->DrawRectangle(leftX, topY, CamWidth, CamDiameter);


    if(holeAngleTurns > 0.5)
    {
        double holeTopY = -cos(holeAngle + holeAngleRange / 2) * CamDiameter / 2;
        double holeBotY = -cos(holeAngle - holeAngleRange / 2) * CamDiameter / 2;

        graphics->SetBrush(*wxBLACK_BRUSH);
        graphics->DrawEllipse(x - HoleSize/2, y + holeTopY, HoleSize, holeBotY - holeTopY);
    }

    if(drop && !mLastDrop)
    {
        for(auto toDrop: mKeyDrops)
        {
            toDrop->KeyDrop();
        }
    }

    mLastDrop = drop;
}
