/**
 * @file MusicBox.cpp
 * @author Charles Owen
 */

#include "pch.h"
#include "MusicBox.h"

/// The music box mechanism image filename
const std::wstring MusicBoxImage = L"/images/mechanism.png";

/// Size to draw the music box mechanism image in pixels
const int MusicBoxImageSize = 120;

/// The color of the rotating music box drum
const wxColour MusicBoxDrumColor = wxColour(248, 242, 191);

/// The color of the lines on the music box rotating drum
const wxColour MusicBoxDrumLineColor = wxColour(20, 20, 20);

/// The music box drum width
const int MusicBoxDrumWidth = 40;

/// The music box drum diameter
const int MusicBoxDrumDiameter = 33;

/// Number of beats per turn of the music box drum
/// This also determines how many lines to draw on the cylinder
const int BeatsPerRotation = 12;

/// The audio directory in the resources
const std::wstring AudioDirectory = L"/audio/";


/**
 * Constructor
 * @param resourcesDir The resources directory
 * @param song Song file to load
 */
MusicBox::MusicBox(std::wstring resourcesDir, std::wstring song) : mResourcesDir(resourcesDir)
{
    mMechanism.SetImage(resourcesDir + MusicBoxImage);
    mMechanism.CenteredSquare(MusicBoxImageSize);

    mDrum.SetColour(MusicBoxDrumColor);
    mDrum.SetSize(MusicBoxDrumDiameter, MusicBoxDrumWidth);
    mDrum.SetBorderColor(wxTRANSPARENT);
    mDrum.SetLines(MusicBoxDrumLineColor, 1, BeatsPerRotation);

    LoadSong(resourcesDir + song);
}

/**
 * Set the mute status
 * @param mute
 */
void MusicBox::SetMute(bool mute)
{
    mMute = mute;
}

/**
 * Load a song from XML.
 * @param file
 */
void MusicBox::LoadSong(std::wstring file)
{
    wxXmlDocument xmlDoc;
    if (!xmlDoc.Load(file))
    {
        wxMessageBox(L"Unable to load song file: " + file);
        return;
    }

    auto root = xmlDoc.GetRoot();
    auto beatsStr = root->GetAttribute(L"beats", "4");
    int beats;
    beatsStr.ToInt(&beats);

    auto child = root->GetChildren();
    for (; child; child=child->GetNext())
    {
        auto name = child->GetName();
        if (name == L"sounds")
        {
            XmlSounds(child);
        }
        else if(name == L"notes")
        {
            XmlNotes(child, beats);
        }
    }
}
/**
 * Handle the sounds XML tag
 * @param items_node Note containing the items
 */
void MusicBox::XmlSounds(wxXmlNode* items_node)
{
    auto child = items_node->GetChildren();
    for ( ; child; child=child->GetNext() )
    {
        auto name = child->GetName();
        if(name == L"sound")
        {
            auto note = child->GetAttribute(L"note", "");
            auto file = child->GetAttribute(L"file", L"");
            mSounds.emplace(note.ToStdWstring(),
                            mResourcesDir + AudioDirectory + file.ToStdWstring());
        }
    }
}

/**
 * Handle the notes XML tag
 * @param node Node containing the song
 * @param beats Number of beats per measure
 */
void MusicBox::XmlNotes(wxXmlNode* node, int beats)
{
    auto child = node->GetChildren();
    for ( ; child; child=child->GetNext() )
    {
        auto name = child->GetName();
        if(name == L"note")
        {
            double beat;
            int measure;

            auto note = child->GetAttribute(L"note", "");
            auto beatStr = child->GetAttribute(L"beat", L"1");
            auto measureStr = child->GetAttribute(L"measure", L"1");

            beatStr.ToDouble(&beat);
            measureStr.ToInt(&measure);
            double absoluteBeat = (measure - 1) * beats + (beat - 1);
            mNotes.push_back({absoluteBeat, note.ToStdWstring()});
        }
    }
}

/**
 * Set the rotation
 * @param rotation Rotation it turns
 */
void MusicBox::SetRotation(double rotation)
{
    mRotation = rotation;

    double beat = (double)mRotation * BeatsPerRotation;
    while((mCurrentNote+1) < mNotes.size() && mNotes[mCurrentNote+1].first <= beat)
    {
        auto note = mNotes[mCurrentNote+1].second;
        auto sound = mSounds.find(note);
        if(sound != mSounds.end())
        {
            if(!mMute)
            {
                sound->second.Play();
            }
        }

        mCurrentNote++;
    }
}

/**
 * Reset to beginning
 */
void MusicBox::Reset()
{
    Component::Reset();
    mCurrentNote = -1;
}

/**
 * Draw the music box
 * @param graphics Graphics device to draw on
 */
void MusicBox::Draw(std::shared_ptr<wxGraphicsContext> graphics)
{
    Component::Draw(graphics);

    auto x = GetX();
    auto y = GetY();

    mMechanism.DrawPolygon(graphics, x, y);
    mDrum.Draw(graphics, x - MusicBoxDrumWidth / 2, y, mRotation);
}
