/**
 * @file Shaft.cpp
 * @author Charles Owen
 */

#include "pch.h"
#include "Shaft.h"

/// The color to draw the shaft
const wxColour ShaftColor = wxColour(220, 220, 220);

/// The color to draw the lines on the shaft
/// First parameter to Cylinder::SetLines
const wxColour ShaftLineColor = wxColour(100, 100, 100);

/// The width to draw the lines on the shaft
/// Second parameter to Cylinder::SetLines
const int ShaftLinesWidth = 1;

/// The number of lines to draw on the shaft
/// Third parameter to Cylinder::SetLines
const int ShaftNumLines = 4;

/**
 * Constructor
 */
Shaft::Shaft()
{
    mCylinder.SetColour(ShaftColor);

    /*
     * The SetLines parameters are:
     * @param color Color of the lines
     * @param width How wide to draw the lines
     * @param num Number of lines to draw
     */
    mCylinder.SetLines(ShaftLineColor, ShaftLinesWidth, ShaftNumLines);
}

/**
 * Set the shaft rotation
 * @param rotation Rotation in turns
 */
void Shaft::SetRotation(double rotation)
{
    mRotation = rotation;
    mSource.SetRotation(mRotation);
}

/**
 * Draw the shaft
 * @param graphics Graphics context to draw on
 */
void Shaft::Draw(std::shared_ptr<wxGraphicsContext> graphics)
{
    Component::Draw(graphics);

    mCylinder.Draw(graphics, GetX(), GetY(), mRotation);
}

