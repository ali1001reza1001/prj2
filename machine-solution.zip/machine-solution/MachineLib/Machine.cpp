/**
 * @file Machine.cpp
 *
 * @author Anik Momtaz
 * @author Charles Owen
 */

#include "pch.h"
#include "Machine.h"
#include "Component.h"
#include "IMutable.h"


/**
 * Reset the machine
 */
void Machine::Reset()
{
	for (auto component : mComponents)
	{
		component->Reset();
	}
}

/**
 * Add a component to the machine
 * @param component Component to add
 */
void Machine::AddComponent(std::shared_ptr<Component> component)
{
	mComponents.push_back(component);
	component->SetMachine(this);
}

/**
 * Draw the machine
 * @param graphics Graphics context to draw on
 */
void Machine::Draw(std::shared_ptr<wxGraphicsContext> graphics)
{
    for (auto component : mComponents)
    {
        component->Draw(graphics);
    }

    for (auto component : mComponents)
    {
        component->DrawLast(graphics);
    }
}

/**
 * Set the machine time
 * @param time The machine time
 */
void Machine::SetTime(double time)
{
    for (auto component : mComponents)
    {
        component->SetTime(time);
    }
}

/**
 * Advance the animation in time
 * @param delta Amount to advance in seconds
 */
void Machine::Advance(double delta)
{
	for (auto component : mComponents)
	{
        component->Advance(delta);
	}
}

/**
 * Set the mute status for all mutable components.
 * @param mute True to mute
 */
void Machine::SetMute(bool mute)
{
    for(auto canMute : mMutables)
    {
        canMute->SetMute(mute);
    }
}