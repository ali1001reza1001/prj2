/**
 * @file pch.h
 *
 * @author Anik Momtaz
 */

#ifndef MACHINELIB_PCH_H
#define MACHINELIB_PCH_H

#include <wx/wxprec.h>
#ifndef WX_PRECOMP
#include <wx/wx.h>
#endif

#include <wx/graphics.h>

#endif //MACHINELIB_PCH_H
