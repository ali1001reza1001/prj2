/**
 * @file MachinesFactory.h
 *
 * @author Anik Momtaz
 * @author Charles B. Owen
 */

#pragma once

#include <memory>

class Machine;
class Shape;

/**
 * Factory class to create the machines we use
 */
class MachinesFactory
{
private:
    /// Path to the resources directory
    std::wstring mResourcesDir;

    /// Path to the images directory
    std::wstring mImagesDir;

	std::shared_ptr<Machine> Create10();
	std::shared_ptr<Machine> Create11();
	std::shared_ptr<Machine> Create12();
	std::shared_ptr<Machine> Create13();
	std::shared_ptr<Machine> Create14();
	std::shared_ptr<Machine> Create15();
	std::shared_ptr<Machine> Create16();
    std::shared_ptr<Machine> Create17();
    std::shared_ptr<Machine> Create18();
    std::shared_ptr<Machine> Create19();


public:
    MachinesFactory(std::wstring resourcesDir);

    std::shared_ptr<Machine> Create(int machine);
};

