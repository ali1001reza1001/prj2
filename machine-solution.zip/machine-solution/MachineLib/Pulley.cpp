/**
 * @file Pulley.cpp
 * @author Charles Owen
 */

#include "pch.h"
#include "Pulley.h"

/// How wide the hub is on each side of the pulley
const double PulleyHubWidth = 3;

/// How deep the belt is into the pulley
const double PulleyBeltDepth = 3;

/// The color to use for pulleys
const wxColour PulleyColor = wxColour(205, 250, 5);

/// The line color to use for the hub
/// First parameter to Cylinder::SetLines
const wxColour PulleyHubLineColor = wxColour(139, 168, 7);

/// The width to draw the lines on the hub
/// Second parameter to Cylinder::SetLines
const int PulleyHubLineWidth = 4;

/// The number of lines to draw on a pulley is the int(diameter / 6.0)
/// Third parameter to Cylinder::SetLines
const double PulleyHubLineCountDiviser = 6.0;


/**
 * Constructor
 * @param diameter The pully diameter to draw
 * @param width The total width of the pulley
 */
Pulley::Pulley(double diameter, double width) : mDiameter(diameter), mWidth(width)
{
    mHubs.SetSize(diameter + PulleyBeltDepth * 2, PulleyHubWidth);
    mHubs.SetColour(PulleyColor);
    mHubs.SetLines(PulleyHubLineColor, PulleyHubLineWidth, int(diameter / PulleyHubLineCountDiviser));

    mCenter.SetSize(diameter, width - PulleyHubWidth * 2);
    mCenter.SetColour(PulleyColor);
}

/**
 * Set the rotation from a source
 * @param rotation Rotation to set in turns
 */
void Pulley::SetRotation(double rotation)
{
    mRotation = rotation;

    if(mOtherPulley != nullptr)
    {
        double speed = mDiameter / mOtherPulley->mDiameter;
        mOtherPulley->SetRotation(mRotation * speed);
    }

    mSource.SetRotation(mRotation);
}

/**
 * Draw the pulley
 * @param graphics Graphics device to draw on
 * @param x X location of the machine in pixels
 * @param y Y location of the machine in pixels
 */
void Pulley::Draw(std::shared_ptr<wxGraphicsContext> graphics)
{
    Component::Draw(graphics);

    graphics->SetBrush(*wxWHITE_BRUSH);
    graphics->SetPen(*wxBLACK_PEN);

    double centerWidth = mWidth - PulleyHubWidth * 2;

    double leftX = GetX() - mWidth / 2;
    double topY = GetY() - mDiameter / 2;
    double rightX = leftX + mWidth;
    double bottomY = topY + mDiameter;

    mHubs.Draw(graphics, leftX, GetY(), mRotation);
    mHubs.Draw(graphics, rightX - PulleyHubWidth, GetY(), mRotation);
    mCenter.Draw(graphics, GetX() - centerWidth / 2, GetY(), mRotation);

    //
    // The belt
    //
    if(mOtherPulley != nullptr)
    {
        graphics->SetBrush(*wxBLACK_BRUSH);
        graphics->SetPen(*wxBLACK_PEN);

        double beltLeftX = leftX + PulleyHubWidth;

        if(GetY() < mOtherPulley->GetY())
        {
            double otherBottomY = mOtherPulley->GetY() + mOtherPulley->mDiameter / 2;

            graphics->DrawRectangle(beltLeftX, topY, centerWidth, otherBottomY - topY);
        }
        else
        {
            double otherTopY = mOtherPulley->GetY() - mOtherPulley->mDiameter / 2;

            graphics->DrawRectangle(beltLeftX, otherTopY, centerWidth, bottomY - otherTopY);
        }

    }

}
