/**
 * @file MusicBox.h
 * @author Charles Owen
 *
 * The music box that plays the music.
 */

#ifndef CANADIANEXPERIENCE_MACHINEDEMO_MUSICBOX_H
#define CANADIANEXPERIENCE_MACHINEDEMO_MUSICBOX_H

#include <map>
#include "wx/xml/xml.h"
#include "wx/sound.h"

#include "Component.h"
#include "Polygon.h"
#include "IRotationSink.h"
#include "IMutable.h"
#include "Cylinder.h"


/**
 * The music box that plays the music.
 */
class MusicBox : public Component, public IRotationSink, public IMutable
{
private:
    /// Directory containing the resources
    std::wstring mResourcesDir;

    /// The music box mechanism image
    cse335::Polygon mMechanism;

    /// A rod to use as the music box drum
    cse335::Cylinder mDrum;

    /// The rotation
    double mRotation = 0;

    void XmlSounds(wxXmlNode *items_node);
    void XmlNotes(wxXmlNode *node, int beats);

    /// The sounds
    std::map<std::wstring, wxSound> mSounds;

    /// The song
    std::vector<std::pair<double, std::wstring>> mNotes;

    /// The current note, -1 for before the song starts
    int mCurrentNote = -1;

    /// Is the sound muted?
    bool mMute = false;

public:
    MusicBox(std::wstring resourcesDir, std::wstring song);
    void Draw(std::shared_ptr<wxGraphicsContext> graphics) override;
    void SetRotation(double rotation) override;
    void LoadSong(std::wstring file);
    void Reset() override;
    void SetMute(bool mute) override;

};

#endif //CANADIANEXPERIENCE_MACHINEDEMO_MUSICBOX_H
