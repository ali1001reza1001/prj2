/**
 * @file MachinesFactory.cpp
 *
 * @author Anik Momtaz
 * @author Charles B. Owen
 */

#include "pch.h"
#include "MachinesFactory.h"
#include "Machine1Factory.h"
#include "Machine1AFactory.h"
#include "Machine2Factory.h"
#include "MachineCFactory.h"
#include "Machine.h"
#include "Box.h"
#include "Sparty.h"
#include "Crank.h"
#include "Shaft.h"
#include "Pulley.h"
#include "Cam.h"
#include "MusicBox.h"
#include "TrigDemo.h"
#include "CylinderDemo.h"


/// The images directory in resources
const std::wstring ImagesDirectory = L"/images";


/**
 * Constructor
 * @param resourcesDir Directory containing the machine resources
 */
MachinesFactory::MachinesFactory(std::wstring resourcesDir) : mResourcesDir(resourcesDir)
{
    mImagesDir = resourcesDir + ImagesDirectory;
}


/**
 * Create a machine
 * @param machine Machine number to create
 * @return Pointer to newly created machine
 */
std::shared_ptr<Machine> MachinesFactory::Create(int machine)
{
    switch (machine)
    {
        case 1:
        default:
        {
            Machine1Factory factory(mResourcesDir);
            return factory.Create();
        }

        case 2:
        {
            Machine2Factory factory(mResourcesDir);
            return factory.Create();
        }

        case 3:
        {
            MachineCFactory factory(mResourcesDir);
            return factory.Create();
        }

        case 10:
            return Create10();

        case 11:
            return Create11();

        case 12:
            return Create12();

        case 13:
            return Create13();

        case 14:
            return Create14();

        case 15:
            return Create15();

        case 16:
            return Create16();

        case 17:
            return Create17();

        case 18:
            return Create18();

        case 20:
        {
            Machine1AFactory factory(mResourcesDir);
            return factory.Create();
        }

    }
}

/**
 * Create demo machine 10
 * @return Machine 10
 */
std::shared_ptr<Machine> MachinesFactory::Create10()
{
    // The machine itself
    auto machine = std::make_shared<Machine>();

    /*
     * The Box class constructor parameters are:
     * @param imagesDir Directory containing the images
     * @param boxSize Size of the box in pixels (just the box, not the lid)
     * @param lidSize Size of the lid in pixels
     */
    auto box = std::make_shared<Box>(mImagesDir, 250, 240);

    // This simulates the cam key drop so the box will immediately open
    box->KeyDrop();
    machine->AddComponent(box);

    return machine;
}

/**
 * Create demo machine 11
 * @return Machine 11
 */
std::shared_ptr<Machine> MachinesFactory::Create11()
{
    // The machine itself
    auto machine = std::make_shared<Machine>();

    /*
     * The Sparty class constructor parameters are:
     * @param image Image file to load
     * @param size Size to draw Sparty (width and height)
     * @param springLength How long the spring is when fully extended in pixels
     * @param springWidth How wide the spring is in pixels
     * @param numLinks How many links (loops) there are in the spring
     */
    auto sparty =
        std::make_shared<Sparty>(mImagesDir + L"/sparty.png", 212, 260, 80, 15);

    // This simulates the cam key drop so Sparty will immediately pop up
    sparty->KeyDrop();
    machine->AddComponent(sparty);

    return machine;
}

/**
 * Create demo machine 12
 * @return Machine 12
 */
std::shared_ptr<Machine> MachinesFactory::Create12()
{
    // The machine itself
    auto machine = std::make_shared<Machine>();

    const int Shaft1Y = -100;

    // The hand crank
    auto crank = std::make_shared<Crank>();
    crank->SetPosition(0, Shaft1Y);
    crank->SetSpeed(0.5);       // In turns per second

    // Add the crank after the shaft is added so it is on top of the shaft
    machine->AddComponent(crank);

    return machine;
}


/**
 * Create demo machine 13
 * Crank demo
 * @return Machine 13
 */
std::shared_ptr<Machine> MachinesFactory::Create13()
{
    // The machine itself
    auto machine = std::make_shared<Machine>();

    const int Shaft1Y = -100;

    // The hand crank
    auto crank = std::make_shared<Crank>();
    crank->SetPosition(50, Shaft1Y);
    crank->SetSpeed(0.5);       // In turns per second

    // The first shaft
    auto shaft1 = std::make_shared<Shaft>();
    shaft1->SetPosition(-50, Shaft1Y);       // Left-center end of the shaft
    shaft1->SetSize(10, 110);                // Diameter, length
    shaft1->SetOffset(0.3);                 // Rotation offset so the
    // lines don't all line up
    machine->AddComponent(shaft1);

    // Connect crank to shaft
    crank->GetSource()->AddSink(shaft1);

    // Note: If you made sinks through composition rather than
    // inheriting an interface, your code would likely be more
    // like this:
    // crank->GetSource()->AddSink(shaft1->GetSink());

    // Add the crank after the shaft is added so it is on top of the shaft
    machine->AddComponent(crank);

    return machine;
}

/**
 * Create demo machine 14
 * @return Machine 14
 */
std::shared_ptr<Machine> MachinesFactory::Create14()
{
    // The machine itself
    auto machine = std::make_shared<Machine>();

    const int Shaft1Y = -150;
    const int Shaft2Y = -50;

    // The hand crank
    auto crank = std::make_shared<Crank>();
    crank->SetPosition(50, Shaft1Y);
    crank->SetSpeed(0.5);       // In turns per second

    // The first shaft
    auto shaft1 = std::make_shared<Shaft>();
    shaft1->SetPosition(-50, Shaft1Y);       // Left-center end of the shaft
    shaft1->SetSize(10, 110);                // Diameter, length
    shaft1->SetOffset(0.3);                 // Rotation offset so the
    // lines don't all line up
    machine->AddComponent(shaft1);

    // Connect crank to shaft
    crank->GetSource()->AddSink(shaft1);

    // Note: If you made sinks through composition rather than
    // inheriting an interface, your code would likely be more
    // like this:
    // crank->GetSource()->AddSink(shaft1->GetSink());

    // Add the crank after the shaft is added so it is on top of the shaft
    machine->AddComponent(crank);

    /*
     * The first pulley
     * @param diameter The pully diameter to draw
     * @param width The total width of the pulley
     */
    auto pulley1 = std::make_shared<Pulley>(30, 15);
    pulley1->SetPosition(0, Shaft1Y);

    shaft1->GetSource()->AddSink(pulley1);

    // The second pulley
    auto pulley2 = std::make_shared<Pulley>(80, 15);
    pulley2->SetPosition(pulley1->GetX(), Shaft2Y);
    pulley1->BeltTo(pulley2);

    auto shaft2 = std::make_shared<Shaft>();
    shaft2->SetPosition(-115, Shaft2Y);       // Left end of the shaft
    shaft2->SetSize(10, 230);                // Diameter and length
    shaft2->SetOffset(0.1);
    machine->AddComponent(shaft2);

    pulley2->GetSource()->AddSink(shaft2);

    machine->AddComponent(pulley2);
    machine->AddComponent(pulley1);

    return machine;
}


/**
 * Create demo machine 15
 * Cam demo
 * @return Machine 15
 */
std::shared_ptr<Machine> MachinesFactory::Create15()
{
    // The machine itself
    auto machine = std::make_shared<Machine>();

    const int Shaft1Y = -100;

    // The hand crank
    auto crank = std::make_shared<Crank>();
    crank->SetPosition(50, Shaft1Y);
    crank->SetSpeed(0.15);       // In turns per second

    // The first shaft
    auto shaft1 = std::make_shared<Shaft>();
    shaft1->SetPosition(-50, Shaft1Y);       // Left-center end of the shaft
    shaft1->SetSize(10, 110);                // Diameter, length
    shaft1->SetOffset(0.3);                 // Rotation offset so the
    // lines don't all line up
    machine->AddComponent(shaft1);

    // Connect crank to shaft
    crank->GetSource()->AddSink(shaft1);


    // Add the crank after the shaft is added so it is on top of the shaft
    machine->AddComponent(crank);

    auto cam = std::make_shared<Cam>(mImagesDir);
    cam->SetPosition(0, Shaft1Y);     // Center of the cam
    cam->SetHoleAngle(0.44);            // How far the hole is from top-dead-center
    // in turns. This means the cam would need
    // to rotate 0.44 turns before the key drops.
    machine->AddComponent(cam);

    shaft1->GetSource()->AddSink(cam);

    return machine;
}

/**
 * Create demo machine 16
 * Cam demo
 * @return Machine 16
 */
std::shared_ptr<Machine> MachinesFactory::Create16()
{
    // The machine itself
    auto machine = std::make_shared<Machine>();

    const int Shaft1Y = -100;

    // The hand crank
    auto crank = std::make_shared<Crank>();
    crank->SetPosition(50, Shaft1Y);
    crank->SetSpeed(0.15);       // In turns per second

    // The first shaft
    auto shaft1 = std::make_shared<Shaft>();
    shaft1->SetPosition(-50, Shaft1Y);       // Left-center end of the shaft
    shaft1->SetSize(10, 110);                // Diameter, length
    shaft1->SetOffset(0.3);                 // Rotation offset so the
    // lines don't all line up
    machine->AddComponent(shaft1);

    // Connect crank to shaft
    crank->GetSource()->AddSink(shaft1);


    // Add the crank after the shaft is added so it is on top of the shaft
    machine->AddComponent(crank);

    auto musicBox =
        std::make_shared<MusicBox>(mResourcesDir, L"/songs/pop.xml");
    musicBox->SetPosition(0, Shaft1Y);      // Center of the music box
    machine->AddComponent(musicBox);
    shaft1->GetSource()->AddSink(musicBox);

    // This optional feature avoids noise when dragging the slider
    // backwards. It mutes the sound when moving time backwards
    machine->AddMutable(musicBox);

    return machine;
}



/**
 * Create demo machine 17
 * @return Machine 17
 */
std::shared_ptr<Machine> MachinesFactory::Create17()
{
    // The machine itself
    auto machine = std::make_shared<Machine>();

    auto demo = std::make_shared<TrigDemo>(mImagesDir);
    machine->AddComponent(demo);

    return machine;
}




/**
 * Create demo machine 18
 * @return Machine 18
 */
std::shared_ptr<Machine> MachinesFactory::Create18()
{
    // The machine itself
    auto machine = std::make_shared<Machine>();

    auto demo = std::make_shared<CylinderDemo>();
    demo->SetPosition(0, -200);
    machine->AddComponent(demo);

    return machine;
}
