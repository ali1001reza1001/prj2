/**
 * @file RotationSource.cpp
 *
 * @author Anik Momtaz
 * @author Charles B. Owen
 */

#include "pch.h"
#include "RotationSource.h"
#include "IRotationSink.h"

/**
 * Set the rotation for all connected sinks
 * @param rotation Rotation in turns
 */
void RotationSource::SetRotation(double rotation)
{
	for (auto sink : mSinks)
	{
		sink->SetRotation(rotation);
	}
}

/**
 * Add a rotation sink
 * @param sink Sink to add
 */
void RotationSource::AddSink(std::shared_ptr<IRotationSink> sink)
{
	mSinks.push_back(sink);
}
