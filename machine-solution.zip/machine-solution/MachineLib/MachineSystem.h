/**
 * @file MachineSystem.h
 *
 * @author Anik Momtaz
 * @author Charles B. Owen
 *
 * The system that manages the machine
 */

#pragma once

#include <memory>

#include "IMachineSystem.h"
#include "Polygon.h"

class Machine;

/**
 * The system that manages the machi
 */
class MachineSystem :
        public IMachineSystem
{
private:
    void Reset();

    /// The actual working machine as allocated
    /// by the factory class.
    std::shared_ptr<Machine> mMachine;

    /// The selected machine number
    int mMachineNumber = 0;

    /// Location of the machine in pixels
    wxPoint mLocation;

    /// Where the resources are stored
    std::wstring mResourcesDir;


    /// Current machine time in seconds
    double mTime = 0;

    /// Current frame
    int mFrame = 0;

    /// Frame rate in frames per second
    double mFrameRate = 30.0;

public:
    MachineSystem(std::wstring resourcesDir);

    void ChooseMachine(int machine) override;
    void SetLocation(wxPoint) override;
    void SetMachineFrame(int frame) override;
    void DrawMachine(std::shared_ptr<wxGraphicsContext> graphics) override;
    int GetMachineNumber() override;
    double GetMachineTime() override;
    void SetFlag(int flag) override;
    void SetFrameRate(double rate) override;

    /**
     * Get the machine location
     * @return Location of the machine
     */
    wxPoint GetLocation() override {return mLocation;}
};

