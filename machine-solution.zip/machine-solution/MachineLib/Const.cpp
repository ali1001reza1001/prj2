/**
 * @file Const.cpp
 *
 * @author Anik Momtaz
 * @author Charles B. Owen
 */

#include "pch.h"
#include "Const.h"

const double Const::PI = M_PI; //  3.1415926535897932384626433832795;
const double Const::PI2 = Const::PI * 2;