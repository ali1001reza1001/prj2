/**
 * @file IRotationSink.h
 * @author Charles Owen
 *
 * Rotation sink interface
 */

#ifndef CANADIANEXPERIENCE_MACHINELIB_IROTATIONSINK_H
#define CANADIANEXPERIENCE_MACHINELIB_IROTATIONSINK_H

/**
 * Rotation sink interface
 */
class IRotationSink
{
public:
    /**
     * Set a rotation due to the source
     * @param rotation
     */
    virtual void SetRotation(double rotation) = 0;
};

#endif //CANADIANEXPERIENCE_MACHINELIB_IROTATIONSINK_H
