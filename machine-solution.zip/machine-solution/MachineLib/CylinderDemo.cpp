/**
 * @file CylinderDemo.cpp
 * @author Charles Owen
 */

#include "pch.h"
#include "CylinderDemo.h"

/**
 * Constructor
 */
CylinderDemo::CylinderDemo()
{
    mCylinder.SetColour(wxColour(255, 200, 200));
    mCylinder.SetSize(200, 500);
    mCylinder.SetLines(wxColour(0, 128, 0), 4, 8);
}

/**
 * Reset the component
 */
void CylinderDemo::Reset()
{
    Component::Reset();
    mRotation = 0;
}

/**
 * Advance the component in time
 * @param delta Amount to advance
 */
void CylinderDemo::Advance(double delta)
{
    Component::Advance(delta);

    mRotation += delta * mSpeed;
}

/**
 * Draw the component
 * @param graphics Graphics device to draw on
 */
void CylinderDemo::Draw(std::shared_ptr<wxGraphicsContext> graphics)
{
    Component::Draw(graphics);

    int x = GetX();
    int y = GetY();

    mCylinder.Draw(graphics, x-250, y, mRotation);
}
