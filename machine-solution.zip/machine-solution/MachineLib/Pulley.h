/**
 * @file Pulley.h
 * @author Charles Owen
 *
 * Vertical pulley
 */

#ifndef CANADIANEXPERIENCE_MACHINELIB_PULLEY_H
#define CANADIANEXPERIENCE_MACHINELIB_PULLEY_H

#include "Component.h"
#include "Cylinder.h"
#include "IRotationSink.h"
#include "RotationSource.h"

/**
 * Vertical pulley
 */
class Pulley : public Component, public IRotationSink
{
private:
    /// The pulley diameter
    double mDiameter;

    /// The pulley width
    double mWidth;

    /// The pulley rotation
    double mRotation = 0;

    /// The pulley hubs on each side
    cse335::Cylinder mHubs;

    /// The pulley center
    cse335::Cylinder mCenter;

    /// The pulley we are connected to
    std::shared_ptr<Pulley> mOtherPulley;

    /// The rotation source for this component
    RotationSource mSource;

public:
    Pulley(double diameter, double width);
    void Draw(std::shared_ptr<wxGraphicsContext> graphics) override;
    void SetRotation(double rotation) override;

    /**
     * Connect this pulley to drive another pulley
     * through the belt.
     * @param pulley Pulley we are connected to
     */
    void BeltTo(std::shared_ptr<Pulley> pulley) {mOtherPulley = pulley;}

    /**
     * Get the rotation source
     * @return Rotation source
     */
    RotationSource* GetSource() {return &mSource;}
};

#endif //CANADIANEXPERIENCE_MACHINELIB_PULLEY_H
