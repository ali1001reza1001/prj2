/**
 * @file SineDemo.h
 * @author Charles Owen
 *
 * Demonstration of simple trig functions
 */

#ifndef CANADIANEXPERIENCE_MACHINELIB_TRIGDEMO_H
#define CANADIANEXPERIENCE_MACHINELIB_TRIGDEMO_H

#include "Component.h"

/**
 * Demonstration of simple trig functions
 */
class TrigDemo : public Component
{
private:
    /// The current time
    double mTime = 0;

public:
    TrigDemo(std::wstring imagesDir);
    void SetTime(double time) override;
    void Draw(std::shared_ptr<wxGraphicsContext> graphics) override;
    void Reset() override;
};

#endif //CANADIANEXPERIENCE_MACHINELIB_TRIGDEMO_H
