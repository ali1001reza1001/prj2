/**
 * @file RotationSource.h
 *
 * @author Anik Momtaz
 * @author Charles B. Owen
 */

#pragma once

#include <vector>

class IRotationSink;

/**
 * Rotation source for a part.
 */
class RotationSource
{
private:
    /// All connected sinks
    std::vector<std::shared_ptr<IRotationSink>> mSinks;

public:
    /// Constructor
	RotationSource() = default;

    /// Copy constructor (disabled)
    RotationSource(const RotationSource &) = delete;

    /// Assignment operator (disabled)
    void operator=(const RotationSource &) = delete;

	void SetRotation(double rotation);

	void AddSink(std::shared_ptr<IRotationSink> sink);
};

