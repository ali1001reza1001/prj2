/**
 * @file SineDemo.cpp
 * @author Charles Owen
 */

#include "pch.h"
#include "TrigDemo.h"
#include <sstream>
#include <iomanip>

/**
 * Constructor
 * @param imagesDir Images directory
 */
TrigDemo::TrigDemo(std::wstring imagesDir)
{

}

/**
 * Reset to time zero
 */
void TrigDemo::Reset()
{
    Component::Reset();
    mTime = 0;
}

/**
 * Set the current time
 * @param time Time in seconds
 */
void TrigDemo::SetTime(double time)
{
    Component::SetTime(time);

    mTime = time;
}

/**
 * Draw the demonstration
 * @param graphics Graphics device to draw on
 */
void TrigDemo::Draw(std::shared_ptr<wxGraphicsContext> graphics)
{
    Component::Draw(graphics);

    int circleX =  -100;
    int circleY =  -250;
    int edgeX =  +250;
    int edgeY = circleY;
    int radius = 200;
    int thickness = 50;
    int axisLen = 450;
    double Speed = 0.125;
    int barSize = 10;

    double turns = mTime * Speed;
    double angle = turns * M_PI * 2;
    double sn = sin(angle);
    double cs = cos(angle);

    graphics->SetBrush(*wxWHITE_BRUSH);
    graphics->SetPen(*wxWHITE_PEN);
    graphics->DrawRectangle(circleX - radius - 40, circleY - radius - 50,
                            edgeX - circleX + radius + 100, radius * 2 + 150);


    // Circle
    wxPen circlePen(wxColour(120, 120, 120));
    graphics->SetPen(circlePen);
    graphics->DrawEllipse(circleX - radius, circleY - radius, radius*2, radius*2);

    // Axis
    graphics->SetPen(*wxRED_PEN);
    graphics->StrokeLine(circleX - axisLen/2, circleY, circleX + axisLen /2, circleY);
    graphics->StrokeLine(circleX, circleY - axisLen/2, circleX, circleY + axisLen /2);

    double bottomLineY = circleY + radius + 40;
    double rightLineX = circleX + radius + 40;

    graphics->StrokeLine(circleX - radius, bottomLineY, circleX + radius, bottomLineY);
    graphics->StrokeLine(rightLineX, circleY - radius, rightLineX, circleY + radius);

    double bottomLineX = circleX + sn * radius;
    double rightLineY = circleY - cs * radius;

    wxPen markerPen(*wxBLACK, 3);
    graphics->SetPen(markerPen);
    graphics->StrokeLine(bottomLineX, bottomLineY-10, bottomLineX, bottomLineY+10);
    graphics->StrokeLine(rightLineX-10, rightLineY, rightLineX+15, rightLineY);

    wxFont font1(wxSize(0, 20),
                wxFONTFAMILY_SWISS,
                wxFONTSTYLE_NORMAL,
                wxFONTWEIGHT_NORMAL);
    graphics->SetFont(font1, *wxBLACK);

    graphics->DrawText(L"sin\u03B8", bottomLineX - 20, bottomLineY + 12);
    graphics->DrawText(L"-cos\u03B8", rightLineX + 23, rightLineY + 25, M_PI/2);

    wxFont font(wxSize(0, 25),
                wxFONTFAMILY_SWISS,
                wxFONTSTYLE_NORMAL,
                wxFONTWEIGHT_NORMAL);
    graphics->SetFont(font, *wxBLACK);

    // Rotating arrow
    wxPen axisPen(wxColour(0, 128, 0), 3);
    graphics->SetPen(axisPen);

    graphics->PushState();
    graphics->Translate(circleX, circleY);
    graphics->Rotate(angle);

    graphics->StrokeLine(0, 0, 0, -radius);
    graphics->StrokeLine(0, -radius, 10, -radius+10);
    graphics->StrokeLine(0, -radius, -10, -radius+10);

    graphics->PopState();

    {
        std::wstringstream str;
        str.setf(std::ios::fixed);
        str << std::setw(3) << std::setfill(L'0') << std::setprecision(2) << turns << L" turns" << std::ends;
        graphics->DrawText(str.str(), circleX + 5, circleY + 5);
    }

    {
        std::wstringstream str;
        str.setf(std::ios::fixed);
        str << std::setw(3) << std::setfill(L'0') << std::setprecision(2) << turns * M_PI * 2 << L" radians" << std::ends;
        graphics->DrawText(str.str(), circleX + 5, circleY + 35);
    }

    {
        std::wstringstream str;
        str.setf(std::ios::fixed);
        str << std::setw(4) << std::setprecision(0) << turns * 360 << L" degrees" << std::ends;
        graphics->DrawText(str.str(), circleX + 5, circleY + 65);
    }


    // Bar
    double barX = circleX + sn * radius;
    double barY = circleY - cs * radius;

    graphics->SetPen(*wxBLUE_PEN);
    graphics->SetBrush(*wxBLUE_BRUSH);

    graphics->DrawEllipse(barX - barSize /2, barY - barSize / 2, barSize, barSize);

    // Circle on edge
    graphics->SetBrush(*wxTRANSPARENT_BRUSH);
    graphics->DrawRectangle(edgeX - thickness/2, edgeY - radius, thickness, radius * 2);

    if(sn >= 0)
    {
        // The bar
        wxPen barPen(*wxBLUE, barSize);
        barPen.SetCap(wxCAP_BUTT);
        graphics->SetPen(barPen);
        graphics->StrokeLine(edgeX - thickness/2, barY, edgeX + thickness/2, barY);
    }



}
