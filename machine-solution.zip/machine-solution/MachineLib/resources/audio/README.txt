All are like this:
F4 hard - kalimba by hollandm -- https://freesound.org/s/691800/ -- License: Creative Commons 0